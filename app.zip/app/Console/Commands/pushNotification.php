<?php

namespace App\Console\Commands;

use App\Http\Controllers\API\PushNotificationController;
use Illuminate\Console\Command;

class pushNotification extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'pushNotificationWeekly:send';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cron job to send notifications to end user.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        // $userDeviceToken = 'dFFiPh8T-gKHWjh0SlJQh-:APA91bHCtkDpXogwh0v0tcmTwav-NW2fCsNMl8xNgQOHFPRlT8jYTIPnEVoseL_qD5SZBJsg6Y0Y8kXC-qjSeKrivB7IFZoNnFSScx7WIyNzlTAw3i61p1iyqJPdCYA2Os12GKqvLbWY';
        // $this->Android($userDeviceToken);
        $userDeviceToken = 'f3UP4adP20y_gavweQHmLV:APA91bF_8KNjYgtCmdu2kv4ONDFzxEZsnMlpjgp_vQ3-xa6bxcpXlMwyOzVvuqRQhzUfXtyaOK8MurzoKEiwkZDdVIWXRd7LXkLJnwTJAo7GVF4ahsNBG_qlbAffskx3quFvT83Se5_r';                    
        $NotificationArray = array();                                                        
        $NotificationArray["body"] = 'puffie';
        $NotificationArray["title"] = "Welcome to puffie";
        $NotificationArray["sound"] = "default";

        $fields = array(
            'to' => $userDeviceToken,
            'notification' => $NotificationArray
        );

        //API URL of FCM
        $url = 'https://fcm.googleapis.com/fcm/send';
        /*api_key available in: Firebase Console -> Project Settings -> CLOUD MESSAGING -> Server key*/
       // $api_key    = FCM_API_KEY');
         $api_key    = 'AAAAuVlW47o:APA91bFtknHnAJp1eOyYPSaZOkrkkamzzm4NIgmj-21R0ivbNa-EwWaeE-O-RtXSIFtj_u47Zdqq3K8KlhbNajUqF9UKTiyC9TP4lEJEFDkthqvV20PWMGJ_eKEMB6dW6vH0pfv1wxyJ';
        //header includes Content type and api key
        $headers = array(
            'Content-Type:application/json',
            'Authorization:key='.$api_key
        );
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
        $result = curl_exec($ch);
    
        if ($result === FALSE) {
             return false;
          // die('FCM Send Error: ' . curl_error($ch));
        }
        curl_close($ch);

      //echo "<pre>"; print_r($result);      
        if ($result === FALSE){
            $response['success']        = false;
            $response['status_code']    = '401';
           //return false;
           return $response;
        }else{
             $response['success']        = true;
             $response['status_code']    = '201';
             $response['message']        = "Successfully send.";
          //return true;
          return $response;
        }
    }
}
