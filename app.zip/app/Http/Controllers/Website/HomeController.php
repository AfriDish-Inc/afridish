<?php

namespace App\Http\Controllers\Website;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Brand;
use App\Models\User;
use App\Models\Category;
use App\Models\Product;
use App\Models\Testimonial;
use Auth;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use Carbon\Carbon;

class HomeController extends Controller
{
     public function index(Request $request)
     {  if(auth()->user()){
           if(auth()->user()->user_type == "C"){
              $brands = Brand::paginate(10);
              $categories = Category::where('is_active',1)->paginate(10);
              if($request->search){
                $products = Product::where('name','LIKE', "%$request->search%")->paginate(10);
                return view('Website.product.index',compact(['brands','categories','products']));
              }

              if($request->latitude && $request->longitude){
                
                $vendors = User::selectRaw("id,
                         ( 6371 * acos( cos( radians(?) ) *
                         cos( radians( latitude ) )
                         * cos( radians( longitude ) - radians(?)
                         ) + sin( radians(?) ) *
                         sin( radians( latitude ) ) )
                         ) AS distance", [$request->latitude, $request->longitude, $request->latitude])->where('user_type', '=', "V")->having('distance', '<=', 10)->get();
                

                $products = [];
                foreach ($vendors as $key => $value) {

                    $products[]= Product::where('provider_id', $value->id)->get();
                }

                //$products = $products[1];  
                if(count($products) > 0){
                    $products = $products[0]; 
                }else{
                    $products = [];
                }              
                return view('Website.product.index',compact(['brands','categories','products']));
              }

              
              $testimonials = Testimonial::paginate(10);
              return view('Website.index',compact(['brands','categories','testimonials']));
           }else{
              Auth::logout();
              return redirect('/');
           }
        }else{
           $brands = Brand::paginate(10);
           $categories = Category::where('is_active',1)->paginate(10);
           if($request->search){
                $products = Product::where('name','LIKE', "%$request->search%")->paginate(10);
                return view('Website.product.index',compact(['brands','categories','products']));
              }
              if($request->latitude && $request->longitude){
                
                $vendors = User::selectRaw("id,
                         ( 6371 * acos( cos( radians(?) ) *
                         cos( radians( latitude ) )
                         * cos( radians( longitude ) - radians(?)
                         ) + sin( radians(?) ) *
                         sin( radians( latitude ) ) )
                         ) AS distance", [$request->latitude, $request->longitude, $request->latitude])->where('user_type', '=', "V")->having('distance', '<=', 10)->get();
                

                $products = [];
                foreach ($vendors as $key => $value) {

                    $products[] = Product::where('provider_id', $value->id)->get();
                }


                if(count($products) > 0){
                    $products = $products[0]; 
                }else{
                    $products = [];
                }


                               
                return view('Website.product.index',compact(['brands','categories','products']));
              }
              $testimonials = Testimonial::paginate(10);
           return view('Website.index',compact(['brands','categories','testimonials']));
        }
     }

     public function userRegister(Request $request)
     {
       if($request->isMethod('post')){

        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'email' => 'required|email',
            'password' => 'required',
            'date_of_birth' =>'required|date|before:'.Carbon::now()->subYears(18),
            'mobile_number' => 'required|numeric'
        ]/*,[
                'date_of_birth.before' => trans('Minimum 18 years required'),                
        ]*/);
         if($validator->fails()){ 
           return redirect('/register')->with('message', $validator->errors()->first()); 
         }


         User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => bcrypt($request->password),
            'mobile_number' => $request->mobile_number,
            'user_type' => "C",
            'country_id' => "+234",
            'dob' => $request->date_of_birth,
        ]);
         return redirect('login');
      }else{
         return view('auth.register');
      }
     }
}
