<?php

namespace App\Http\Controllers\Website;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ContactUs;
use Auth;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use Carbon\Carbon;


class ContactUsController extends Controller
{
    public function index(Request $request){
        if ($request->isMethod('post')) {
            $contactus =  ContactUs::firstOrNew(['email' =>  $request->email]);
            $contactus->full_name = $request->full_name;
            $contactus->email = $request->email;
            $contactus->user_query = $request->user_query;
            $contactus->save();
            return redirect()->back()->with('message',"Thanks for connecting us");
        }else{
            return view('Website.contact-us');
        }
     } 
}
