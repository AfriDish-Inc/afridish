<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Product;
use Redirect;
use DB;
use Illuminate\Foundation\Auth\AuthenticatesUsers; 
use Illuminate\Support\Facades\Validator;
use App\Mail\VerifyMail;
use Illuminate\Support\Str;
use Mail;

class ProviderController extends Controller
{
    public function index()
    {
        $provider = User::latest()->where('user_type' , 'V')->paginate(10);
        return view('admin.provider.index')->with(['providers'=>$provider]);
    }

    public function create()
    {
        return view('admin.provider.create');
    }

    public function store(Request $request){
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'email' => 'required|unique:users,email',
            'user_address' => 'required',
            'mobile_number' => 'required|numeric||unique:users,mobile_number',
            'profile_picture' => 'required|mimes:jpeg,png,jpg|max:2048'
        ]);
         if($validator->fails()){ 
           return redirect()->back()->withInput()->with('error', $validator->errors()->first()); 
         }

         if($this->checkemail($request->email)){
            $password = Str::upper(Str::random(16));
            $file = $request->file('profile_picture');
            $filename = $file->getClientOriginalName();
            $filename = time().'_'.$filename;
            $path = 'upload/images';
            $file->move($path, $filename);
            $provider = new User;
            $provider->name = $request->name;
            $provider->email = $request->email;
            $provider->user_type = 'V';
            $provider->profile_picture = $filename;
            $provider->mobile_number = $request->mobile_number;
            $provider->user_address = $request->user_address;
            $provider->password = bcrypt($password);
            $provider->save();
            $message = 'Great! Provider Created Successfully.';
            /*$verifyUser = VerifyUser::create([
                'user_id' => $user->id,
                'token' => sha1(time()),
            ]);*/

            $data= [
                'email' => $request->email,
                'password' => $password,
            ];

            Mail::to($request->email)->send(new VerifyMail($data));
             return Redirect::to('admin/provider')->with('success',$message);
         }else{
            return redirect()->back()->withInput()->with('error', 'Please enter valid email !');
         }
    }

    public function show(User $category)
    {
        //
    }

    public function edit(User $provider)
    {   
       // $providerdata =  User::where('id',$provider->id);
        return view('admin.provider.edit',compact('provider'));
    }

    public function update(Request $request,$id)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'email' => 'required|unique:users,email',
            'user_address' => 'required',
            'mobile_number' => 'required|numeric|unique:users,mobile_number',
            'profile_picture' => 'required|mimes:jpeg,png,jpg|max:2048'
        ]);

         if($validator->fails()){ 
           return redirect()->back()->withInput()->with('error', $validator->errors()->first()); 
         }
         
        $file = $request->file('profile_picture');
        $filename = $file->getClientOriginalName();
        $filename = time().'_'.$filename;
        $path = 'upload/images';
        $file->move($path, $filename);
        if($this->checkemail($request->email)){
          $provider =  User::where('id',$id)->update(['name' =>$request->name,'email' =>$request->email,'mobile_number' =>$request->mobile_number,'user_address' =>$request->user_address,'profile_picture' =>$filename,'password'=>bcrypt("Welcome")]);
          return Redirect::to('admin/provider')->with('success','Great! Provider Updated Successfully.');
        }else{
            return redirect()->back()->withInput()->with('error', 'Please enter valid email !');
        }
    }

    public function destroy(Request $request){
        Product::where('provider_id',$request->id)->delete();  
        User::where('id',$request->id)->delete();
        return Redirect::to('admin/provider')->with('success','Provider deleted successfully');
    }

    public function checkemail($str) {
        return (!preg_match("/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/ix", $str)) ? FALSE : TRUE;
    }
}
