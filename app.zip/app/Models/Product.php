<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    //

	protected $fillable = [
    'name','detail','description','category_id','quantity','price','image','brand_id','provider_id'
	];


	public function category()
    {
		return $this->hasMany('App\Models\Category', 'id', 'category_id');


    }

    public function wishlist()
    {
        return $this->hasMany('App\Models\Wishlist', 'id', 'product_id');


    }

    public function favoriteproduct()
    {
        return $this->hasMany('App\Models\FavouriteProduct');
    }

}
